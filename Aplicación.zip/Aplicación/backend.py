import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split as tts
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression, Ridge
from surprise import KNNBasic, NMF, Dataset, Reader
import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras.layers import Concatenate, Dense, Embedding, Flatten, Input, Multiply, Dropout, Dot
from tensorflow.keras.models import Model
from tensorflow.keras.regularizers import l2
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

path = 'C:/Users/Evichu/Desktop/IMMUNE/CAPSTONE/app/dfs'

def load_df_final():
    return pd.read_excel(os.path.join(path, 'df_limpia.xlsx'))

def load_contaminantes():
    return pd.read_csv(os.path.join(path, 'codigos contaminantes.csv'))

def load_estaciones():
    return pd.read_csv(os.path.join(path, 'Estaciones.csv'))

meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
         'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

# Lista de días
dias = list(range(1, 32))

# Lista de años de 2019 a 2025
anios = list(range(2019, 2026))